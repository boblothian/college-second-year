﻿//Robert Lothian
//HNS Software Development 2
//03.12.21
//Assesment 1

using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment_1
{
    class Animal //this creates a parent object that contains information to be inherited by Mammal and Reptile classes
    {
        private protected int id;
        private protected int danger_rating;
        private protected string animal_name;
        private protected string animal_type;
        private protected char sex;

        public Animal() //this is a constructor that creates default values for each object of Animal created
        {
            id = 0;
            animal_name = "";
            animal_type = "";
            danger_rating = 0;
            sex = 'F';
        }

        public void set_animal_details(ref int num_animals) //this method sets the deatils for the animal by asking for user input and storing detail
        {
            id++;//adds one to each new animal id created

            Console.Write("Enter animals name - "); //animal name
            animal_name = Console.ReadLine();

            Console.Write("Enter animals type - "); //animal type
            animal_type = Console.ReadLine();

            Console.Write("Enter animals sex - "); //animal sex
            sex = char.Parse(Console.ReadLine().ToUpper());

            while (sex != 'F' && sex != 'M')
            {
                Console.WriteLine("You have entered a wrong character, try again"); //this will loop if user enters invalid char
                Console.Write("Enter animals sex - ");
                sex = char.Parse(Console.ReadLine().ToUpper());
            }

            Console.Write("Enter animals danger rating - "); //danger rating
            danger_rating = int.Parse(Console.ReadLine());

            while (danger_rating >5 || danger_rating <=0)
            {
                Console.WriteLine("You have entered an invalid rating, try again"); //this will loop if user enters an invalid damage rating
                Console.Write("Enter animals danger rating - ");
                danger_rating = int.Parse(Console.ReadLine());
            }
        }

        public int get_id() //the following sections get user entered results
        {
            return id++;
        }

        public string get_animal_name()
        {
            return animal_name;
        }

        public string get_animal_type()
        {
            return animal_type;
        }

        public int get_danger_rating()
        {
            return danger_rating;
        }

        public char get_sex()
        {
            return sex;
        } //get-ers end

        public void print_animal_details() //this prints out the data the user entered
        {
            Console.WriteLine("ANIMAL ID - " + get_id());
            Console.WriteLine("ANIMAL NAME - " + get_animal_name());
            Console.WriteLine("ANIMAL TYPE - " + get_animal_type());
            Console.WriteLine("SEX - " + get_sex());
            Console.WriteLine("DANGER RATING - " + get_danger_rating());
        }

        public virtual double calculate_insurance(int danger_rating) //this sets up the calculations of insurance. This will be changed in the child classes by polymorphism
        {
            int base_insurance = 0;
            double insurance = 0;

            switch (danger_rating)
            {

                case 1:
                    insurance = (base_insurance * 10) * 0.02;
                    break;

                case 2:
                    insurance = (base_insurance * 20) * 0.05;
                    break;

                case 3:
                    insurance = (base_insurance * 30) * 0.05;
                    break;

                case 4:
                    insurance = (base_insurance * 40) * 0.05;
                    break;

                case 5:
                    insurance = (base_insurance * 50) * 0.10;
                    break;
            }
            return insurance;
        }
    } //end of class Animal
}//end of namespace
