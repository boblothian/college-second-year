﻿
//Robert Lothian
//HND Software Development 2
//03.12.21
//Assessment 1, Clyde Conservation program


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_1
{
    class Program
    {

        static void Main(string[] args)
        {
            //instantiate a reptile and mammal object - named m1 and r1.
            Mammal m1 = new Mammal();
            Reptile r1 = new Reptile();

            const int quit_option = 4;
            int choice = 0;
            int num_animals = 0;
            while (choice != quit_option)
            {
                Console.WriteLine();
                display_menu();
                get_choice(ref choice);
                act_on_choice(ref num_animals, ref m1, ref r1, choice);
            }
        }
        public static void display_menu()
        //displays the menu system
        {
            Console.WriteLine();
            Console.WriteLine("\t\t\t MAIN MENU");
            Console.WriteLine("\t\t\t 1. Mammal");
            // Console.WriteLine ("\t\t 2.  Allocate Keeper to Cage";       To be included at a later stage
            Console.WriteLine("\t\t\t 3. Reptile");
            Console.WriteLine("\t\t\t 4. Exit ");
        } //end of main menu
        public static void get_choice(ref int this_choice)
        {
            Console.WriteLine("\t\t Enter Choice 1,2, 3 or 4\n");
            this_choice = int.Parse(Console.ReadLine());
        } //end of get choice method
        public static void act_on_choice(ref int num_animals, ref Mammal m1, ref Reptile r1, int this_choice)
        {
            //Takes user input from main menu and calls Mammal or Reptile . This in turn will call the methods for 
            //Mammal or reptile
            switch (this_choice)
            {
                case 1:
                    {
                        int Mchoice;
                        Console.WriteLine();
                        Console.WriteLine("\t\t\tSelect operation \n");
                        Console.WriteLine("\t\t\t1.  Add mammal \n");
                        Console.WriteLine("\t\t\t2. Print mammal \n");
                        Console.WriteLine("\t\t\tEnter choice: ");
                        Mchoice = int.Parse(Console.ReadLine());
                        switch (Mchoice)
                        {
                            case 1:
                                {
                                    //call set mammal details from mammal class
                                    m1.set_mammal_details(ref num_animals);
                                    Console.WriteLine("Press any key to continue....");
                                    Console.ReadKey();
                                    break;
                                }
                            case 2:
                                {
                                    //call print mammal details from mammal class
                                    m1.print_mammal_details();
                                    Console.WriteLine("Press any key to continue....");
                                    Console.ReadKey();
                                    break;
                                }
                        }//end switch statement for mammal type
                        break;
                    } // end case 1 for main menu
                case 3:
                    {
                        int Rchoice;
                        Console.WriteLine();
                        Console.WriteLine("\t\t\tSelect operation  \n");
                        Console.WriteLine("\t\t\t1.  Add Reptile \n");
                        Console.WriteLine("\t\t\t2. Print Reptile \n");
                        Console.WriteLine("\t\t\tEnter choice: ");
                        Rchoice = int.Parse(Console.ReadLine());
                        Console.WriteLine("\n");
                        switch (Rchoice)
                        {
                            case 1:
                                {
                                    //call set reptile details from reptile class
                                    r1.set_reptile_details(ref num_animals);
                                    Console.WriteLine("Press any key to continue....");
                                    Console.ReadKey();
                                    break;
                                }
                            case 2:
                                {
                                    //call print reptile details from reptile class
                                    r1.print_reptile_details();
                                    Console.WriteLine("Press any key to continue....");
                                    Console.ReadKey();
                                    break;
                                }
                        }//end switch statement for Reptile type
                        break;
                    } //end of case 3
                case 4:
                    break;
            }//end of switch
        } //end of act on choice method
    }//end of class
}