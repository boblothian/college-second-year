﻿//Robert Lothian
//HNS Software Development 2
//03.12.21
//Assesment 1

using System;


namespace Assessment_1
{
    class Reptile : Animal
    {
        private protected float tank_temperature;
        private protected string enviroment;

        public Reptile() //instanciates reptile attributes
        {
            tank_temperature = 0;
            enviroment = "";
        }

        public void set_reptile_details(ref int num_animals) //sets reptile sprecific details
        {
            set_animal_details(ref num_animals);

            Console.Write("Enter the tank temperature - ");
            tank_temperature = float.Parse(Console.ReadLine());

            Console.Write("Enter enviroment - water or dry - ");
            enviroment = Console.ReadLine();
        }

        public double get_tank_temperature()
        {
            return tank_temperature;
        }

        public string get_enviroment()
        {
            return enviroment;
        }

        public void print_reptile_details()
        {
            print_animal_details();
            Console.WriteLine("TANK TEMPERATURE: " + get_tank_temperature() + "C");
            Console.WriteLine("ENVIROMENT: " + get_enviroment());
            Console.WriteLine("INSURANCE COST: £" + calculate_insurance(danger_rating));
        }

        public override double calculate_insurance(int danger_rating) //override base animal danger rating using polymorphism
        {
            int base_insurance = 1000;
            double insurance = 0;

            switch (danger_rating)
            {

                case 1:
                    insurance = (base_insurance * 10) * 0.05;
                    break;

                case 2:
                    insurance = (base_insurance * 20) * 0.10;
                    break;

                case 3:
                    insurance = (base_insurance * 30) * 0.15;
                    break;

                case 4:
                    insurance = (base_insurance * 40) * 0.15;
                    break;

                case 5:
                    insurance = (base_insurance * 50) * 0.20;
                    break;
            }

            return insurance;
        }
    }// end of class
}//end of namespace
