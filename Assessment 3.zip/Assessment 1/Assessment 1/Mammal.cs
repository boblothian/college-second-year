﻿//Robert Lothian
//HNS Software Development 2
//03.12.21
//Assesment 1

using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment_1
{
    class Mammal : Animal //this creates a child class that will inherit from the parent Animal class
    {
        private protected string mate_name;
        private protected string given_birth;

        public Mammal() //this instanciates the object Mammal with default values
        {
            mate_name = "";
            given_birth = "";
        }

        public void set_mammal_details(ref int num_animals)
        {
            set_animal_details(ref num_animals);

            Console.Write("Enter the mates name : ");
            mate_name = Console.ReadLine();

            if (sex == 'F')
            {
                    Console.Write("Has the animal given birth? : ");
                    given_birth = Console.ReadLine();   
            }//end of if statement

            else given_birth = "";

            
        }

        public string get_mate_name()
        {
            return mate_name;
        }

        public string get_given_birth()
        {
            return given_birth;
        }

        public void print_mammal_details()
        {
            print_animal_details();
            Console.WriteLine("MATE NAME: " + mate_name);

            if (sex == 'F') //this if statement will ask if mammal has given birth if sex = f
            {
                Console.WriteLine("GIVEN BIRTH: " + given_birth);
            }

            Console.WriteLine("INSURANCE COST: £" + calculate_insurance(danger_rating));
        }

        public override double calculate_insurance(int danger_rating) //calculates insurance based on danger rating
        {
            int base_insurance = 5000;
            double insurance = 0;

            switch (danger_rating)
            {

                case 1:
                    insurance = (base_insurance * 10) * 0.02;
                    break;

                case 2:
                    insurance = (base_insurance * 20) * 0.05;
                    break;

                case 3:
                    insurance = (base_insurance * 30) * 0.05;
                    break;

                case 4:
                    insurance = (base_insurance * 40) * 0.05;
                    break;

                case 5:
                    insurance = (base_insurance * 50) * 0.10;
                    break;
            }

            return insurance;
        }
    }
}
