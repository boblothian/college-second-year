﻿//Robert Lothian
//HND Software Development 2
//11.02.22
//This class is used to create cages for the animals

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_1
{
    class Cage
    {
        private int cage_id;
        int[] cage_count = new int[7]; //array to set the number of cages

        public Cage()//initialise variables
        {
            cage_count[0] = 4;
            cage_count[1] = 2;
            cage_count[2] = 2;
            cage_count[3] = 1;
            cage_count[4] = 3;
            cage_count[5] = 2;
            cage_count[6] = 1;
        }

        public void assign_cage()
        {
            Console.WriteLine("Enter cage ID to be allocated");
            cage_id = int.Parse(Console.ReadLine());
            cage_id--; //take one away from cage ID as arrays start at 0

            cage_count[cage_id] = cage_count[cage_id] - 1; //updates cage count

            if (cage_count[cage_id] < 0) //this if statement determines if there are spaces left in the cage
            {
                cage_count[cage_id] = 0;
                Console.WriteLine("There are no spaces left");
            }

            else
            {
                Console.WriteLine("Remaining spaces in cage " + (cage_id + 1) + " = " + (cage_count[cage_id]));            //changed display text to reflect spaces within a cage available rather than cages as a whole,
            }
            
        }                                                                                                        

        public void check_cage_availability(ref Cage c1)//called from keeper class
        {
            try //this will handle an error if user tries to select cage that is nopt between 1 and 7
            {
                for (int i = 0; i < 7; i++)
                {
                    Console.WriteLine("Cage " + (i + 1) + " has " + c1.cage_count[i] + " spaces\n");
                }

                c1.assign_cage();
            }

            catch (Exception e)
            {
                Console.WriteLine("Cage does not exist");
                Console.WriteLine(e.Message);
            }
            
        }
    }//end class
}
