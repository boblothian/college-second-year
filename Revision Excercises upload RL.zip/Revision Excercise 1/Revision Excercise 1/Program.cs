﻿//Robert Lothian
//HND Soft Dev 2
//26/08/21
//ATM machine, withdraw, deposit and display functionality

using System;

namespace Revision_Excercise_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int userBalance = 800; //on initialisation credit account 800
            menu(userBalance);
        }

        static void menu(int userBalance)
        {
                Console.WriteLine("Please select from the following options \n1. Display Balance \n2. Deposit Cash \n3. Withdraw Cash \n4. Exit"); //display options

                if (Console.ReadLine().Equals("1"))
                {
                    Console.WriteLine("Your balance available is " + userBalance + "\n"); //simple code to display balance
                    menu(userBalance);
                }

                else if (Console.ReadLine().Equals("2"))
                {
                    deposit(userBalance); //go to deposit method
                }

                else if (Console.ReadLine().Equals("3"))
                {
                    withdraw(userBalance); //go to withdraw method
                }

                else if (Console.ReadLine().Equals("4"))
                {
                    Console.WriteLine("Thank you, have a good day!");
                    Environment.Exit(0); //exit program
                }

                else
                {
                    Console.WriteLine("Please enter a valid number"); //contingiency for user misinput
                    menu(userBalance);
                }
           
        }

        static void deposit(int userBalance)
        {
            Console.WriteLine("Please enter the amount you would like to deposit :");

            int depositAmount = Convert.ToInt32(Console.ReadLine()); //get user input
            userBalance = userBalance + depositAmount; //change the user balance amouny

            Console.WriteLine("Your deposit is completed \n Would you like another service? Y/N");

            if (Console.ReadLine().Equals("Y"))
            {
                menu(userBalance); // return to menu
            }

            else
            {
                Environment.Exit(0);
            }
                  
        }

        static void withdraw(int userBalance)
        {
            Console.WriteLine("Please enter the amount you would like to withdraw :");

            int withdrawAmount = Convert.ToInt32(Console.ReadLine());

            if (withdrawAmount > userBalance) //if amount withdrawn exceeds funds display message
            {
                Console.WriteLine("Sorry you have insufficiant funds for this withdrawal \nWould you like to select another amount? Y/N");

                if (Console.ReadLine().Equals("Y")) //repeat balance method
                {
                    withdraw(userBalance);
                }

                else
                {
                    menu(userBalance); // return to menu
                }
                
            }

            userBalance = userBalance + withdrawAmount; //update balance amount

            Console.WriteLine("Your withdrawl is completed \nWould you like another service? Y/N");

            if (Console.ReadLine().Equals("Y"))
            {
                menu(userBalance); // return to menu
            }

            else
            {
                Environment.Exit(0);
            }
        }
    }
}
