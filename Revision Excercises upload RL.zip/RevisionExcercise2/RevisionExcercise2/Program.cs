﻿//Robert Lothian
//HND Soft Dev 2
//27.08.21
//Array sort, displaying ascending and descending results

using System;

namespace RevisionExcercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            myArray();
        }

        static void myArray() //get user input and store values into an array
        {
            Console.WriteLine("Please enter 4 numbers");
            int[] userNumbers = new int[4]; //Creat an array that will store 4 values
            for (int i = 0; i < userNumbers.Length; i++) //loop until 4 values are entered                                                     
            {
                userNumbers[i] = Convert.ToInt32(Console.ReadLine()); 
            }

            sortArray(userNumbers); //send to sorting method
        }

        static void sortArray(int[] userNumbers)
        {
            Console.WriteLine("\nThe numbers in ascending order are...");

            Array.Sort(userNumbers); //sort in asceding order

            foreach (int i in userNumbers)
            {
                Console.WriteLine(i); 
            }

            Console.WriteLine("\nThe numbers in descending order are...");

            Array.Reverse(userNumbers); //sort in descending order

            foreach (int i in userNumbers)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("\n\nThank you for using this program!"); //Exit message
            System.Environment.Exit(0);
        }
    }
}