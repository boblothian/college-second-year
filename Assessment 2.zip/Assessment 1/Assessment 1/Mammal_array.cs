﻿//Robert Lothian
//HND Software Development 2
//11.02.22
//This class is used to create an array list

using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment_1
{
    class Mammal_array
    {
        private int count = 0;
        int num_animals = 0;
        Mammal[] mammal_list = new Mammal[5];

        public Mammal_array()
        {
            count = 0; //counter for array
            num_animals = 5; //max amount in array

            for (int i=0; i< 5; i ++) //loop to instanciate array
            {
                mammal_list[i] = new Mammal(); //create mammal_list
            }
        }

        public void Add_mammal_list()
        {
            

            if (count <= num_animals)
            {
                mammal_list[count].set_mammal_details(ref num_animals);
                mammal_list[count].get_id();
                count++;
            }

            else
            {
                Console.WriteLine("Cannot add, array is full");
            }

        }


        public void show_mammal_list() //this loop prints out mammal details
        {
            for (int i = 0; i <num_animals; i++)
            {
                if ((mammal_list[i].get_id() !=0))
                {
                    mammal_list[i].print_mammal_details();
                    Console.WriteLine("\n");
                }
                
            }//end loop
        }
    }
}
 