﻿//Robert Lothian
//HND Software Development 2
//11.02.22
//This class is used to create keepers

using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment_1
{
    class Keeper
    {
        int keeper_id;
        int count;//added count to cages taken by keeper
        int[] cages_allocated = new int[4]; //sets up to 4 keepers


        public Keeper()
        {
            keeper_id = 0;
            cages_allocated[0] = 0;
            cages_allocated[1] = 0;
            cages_allocated[2] = 0;
            cages_allocated[3] = 0;
        }

        public void set_keeper_id(ref Keeper k1, ref Cage c1)
        {
            //user will input keeper to be assigned to a cage
            Console.WriteLine("Enter the Keeper ID that requires a cage: ");
            keeper_id = int.Parse(Console.ReadLine());
            keeper_id--;
            set_keeper_cage(ref c1);
        }

        public int get_keeper_id()
        {
            keeper_id++;
            return keeper_id; 
        }

        public void set_keeper_cage(ref Cage c1)
        {
            if (cages_allocated[keeper_id] + 1 >= 0 && cages_allocated[keeper_id] + 1 <= 4) //this statement determines if there is available space
            {
                c1.check_cage_availability(ref c1);
                cages_allocated[keeper_id]++;
                count= cages_allocated[keeper_id];//keeps count of cages taken by keeper
                Console.WriteLine("Keeper " + get_keeper_id() + " has " + count + " cage(s)");
            }

            else
            {
                Console.WriteLine("There are no available cages");
            }
        }
    }//end class
}
