﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace FileExtensions
{
    /// <summary> 
    /// Form stores and displays file extensions and default program 
    /// using a key/value generic collection class 
    /// </summary> 

    public partial class frmFileExtensions : Form
    {

        /// <summary> 
        /// default constructor 
        /// </summary> 
        /// 
        public static string getCurrDir = Directory.GetCurrentDirectory();
        public static string fileName = "datafile.dat";
        public static string fullPath = Path.Combine(getCurrDir, fileName);

        public static Dictionary<string, string> myDictionary = new Dictionary<string, string>();

        public frmFileExtensions()
        {
            InitializeComponent();
        }

        /// <summary> 
        /// Event handler method called when for load 
        /// should read entries from data file (if it exists) 
        /// or create a new collection object (the instance variable) 
        /// </summary> 
        private void frmFileExtensions_Load(object sender, EventArgs e)
        {
            ReadDataFile();
        }

        /// <summary> 
        /// Event handler method for adding a new entry 
        /// </summary> 
        private void butAddEntry_Click(object sender, EventArgs e)
        {
            string key = txtExtension.Text;
            string value = txtProgram.Text;

            if(txtExtension.Text == "" || txtProgram.Text == "")
            {
                MessageBox.Show("Both text boxes must be populated, try again.","Error");
            }

            else
            {
                try
                {
                    myDictionary.Add(key, value);
                    lstExtensions.Items.Add(txtExtension.Text + ", " + txtProgram.Text);
                    txtExtension.Clear();
                    txtProgram.Clear();
                    UpdateDataFile();
                    MessageBox.Show("Entry Added");
                }
                catch 
                {
                    MessageBox.Show("Extension already exists");
                }
            }
        }


        /// <summary> 
        /// Event handler method for deleting an existing entry 
        /// </summary> 
        private void butDelCurrent_Click(object sender, EventArgs e)
        {
            if(lstExtensions.SelectedItem != null)
            {
                var keyTemp = lstExtensions.SelectedItem.ToString().Split(',')[0];
                lstExtensions.Items.Remove(lstExtensions.SelectedItem);
                myDictionary.Remove(keyTemp);
                UpdateDataFile();
                txtExtension.Clear();
                txtProgram.Clear();
                MessageBox.Show("Entry Deleted");
            }
            else
            {
                MessageBox.Show("Cannot delete entry, highlight entry and try again","Error");
            }
        }

        /// <summary> 
        /// Event handler method for listing all of the entries in the Extensions List 
        /// </summary> 

        private void butListAll_Click(object sender, EventArgs e)
        {   //TO DO should clear textDisplay and then 
            //should iterate through collection object 
            //and append text to textDisplay text box 
            UpdateDataFile();
            lstExtensions.Items.Clear();
            lstExtensions.Items.Add("Here are the extensions and the program they use"); 
            ReadDataFile();
        }

        /// <summary> 
        /// event handler method for clicking on Find Program button 
        /// </summary> 
        /// 


        private void butFind_Click(object sender, EventArgs e)
        {
            string value;

            if (txtFind.Text == "")
            {
                MessageBox.Show("Please enter a search query");
            }
            
            else
            {
                if (myDictionary.TryGetValue(txtFind.Text, out value))
                {
                    MessageBox.Show("Extension is " + txtFind.Text + " Program is " + value);
                }
                else
                {
                    MessageBox.Show("Items not found");
                }
            }
        }

        /// <summary> 
        /// If confirmed will clear all values in collection 
        /// </summary> 

        private void butClearAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you really want to delete all entries ?", "Confirm delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                lstExtensions.Items.Clear();
                myDictionary.Clear();
                UpdateDataFile();
            }
        }

        /// <summary> 
        /// helper method for writing data to data file 
        /// </summary> 

        private void UpdateDataFile()
        {
            var writeFile = new BinaryFormatter();

            try
            {
                using (var stream = File.OpenWrite(fullPath))
                {
                    writeFile.Serialize(stream, myDictionary);
                }
            }

            catch (IOException e)
            {
                MessageBox.Show("Current Error = " + e);
            }
        }

        /// <summary> 
        /// helper method for reading data from data file 
        /// </summary> 
        /// 
        

        private void ReadDataFile()
        {
            var readFile = new BinaryFormatter();    
            
            try
            {
                using (var stream = File.OpenRead(fullPath))
                {
                    myDictionary = (Dictionary<string, string>)readFile.Deserialize(stream);
                }

                foreach (KeyValuePair<string, string> entry in myDictionary)
                {
                    lstExtensions.Items.Add(entry.Key + ", "+ entry.Value);
                }
            }

            catch (IOException e)
            {
                MessageBox.Show("Current error = " + e);
            }
        }

    }
}
