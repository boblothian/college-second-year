﻿
namespace FileExtensions
{
    partial class frmFileExtensions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstExtensions = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblText1 = new System.Windows.Forms.Label();
            this.txtFind = new System.Windows.Forms.TextBox();
            this.butFind = new System.Windows.Forms.Button();
            this.butListAll = new System.Windows.Forms.Button();
            this.grpBoxEdit = new System.Windows.Forms.GroupBox();
            this.grpBoxDelete = new System.Windows.Forms.GroupBox();
            this.butClearAll = new System.Windows.Forms.Button();
            this.butDelCurrent = new System.Windows.Forms.Button();
            this.lblDeleteEntry = new System.Windows.Forms.Label();
            this.grpBoxAdd = new System.Windows.Forms.GroupBox();
            this.butAddEntry = new System.Windows.Forms.Button();
            this.lblProgram = new System.Windows.Forms.Label();
            this.lblExtension = new System.Windows.Forms.Label();
            this.txtProgram = new System.Windows.Forms.TextBox();
            this.txtExtension = new System.Windows.Forms.TextBox();
            this.grpBoxEdit.SuspendLayout();
            this.grpBoxDelete.SuspendLayout();
            this.grpBoxAdd.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstExtensions
            // 
            this.lstExtensions.FormattingEnabled = true;
            this.lstExtensions.Location = new System.Drawing.Point(17, 52);
            this.lstExtensions.Name = "lstExtensions";
            this.lstExtensions.Size = new System.Drawing.Size(246, 225);
            this.lstExtensions.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(345, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "File Extension Default Program";
            // 
            // lblText1
            // 
            this.lblText1.AutoSize = true;
            this.lblText1.Location = new System.Drawing.Point(14, 308);
            this.lblText1.Name = "lblText1";
            this.lblText1.Size = new System.Drawing.Size(288, 13);
            this.lblText1.TabIndex = 2;
            this.lblText1.Text = "Enter file extensions and then click on Find Default Program";
            // 
            // txtFind
            // 
            this.txtFind.Location = new System.Drawing.Point(17, 349);
            this.txtFind.Name = "txtFind";
            this.txtFind.Size = new System.Drawing.Size(100, 20);
            this.txtFind.TabIndex = 3;
            // 
            // butFind
            // 
            this.butFind.Location = new System.Drawing.Point(138, 342);
            this.butFind.Name = "butFind";
            this.butFind.Size = new System.Drawing.Size(125, 33);
            this.butFind.TabIndex = 4;
            this.butFind.Text = "Find Default Program";
            this.butFind.UseVisualStyleBackColor = true;
            this.butFind.Click += new System.EventHandler(this.butFind_Click);
            // 
            // butListAll
            // 
            this.butListAll.Location = new System.Drawing.Point(138, 390);
            this.butListAll.Name = "butListAll";
            this.butListAll.Size = new System.Drawing.Size(125, 33);
            this.butListAll.TabIndex = 5;
            this.butListAll.Text = "List All";
            this.butListAll.UseVisualStyleBackColor = true;
            this.butListAll.Click += new System.EventHandler(this.butListAll_Click);
            // 
            // grpBoxEdit
            // 
            this.grpBoxEdit.Controls.Add(this.grpBoxDelete);
            this.grpBoxEdit.Controls.Add(this.grpBoxAdd);
            this.grpBoxEdit.Location = new System.Drawing.Point(336, 52);
            this.grpBoxEdit.Name = "grpBoxEdit";
            this.grpBoxEdit.Size = new System.Drawing.Size(306, 371);
            this.grpBoxEdit.TabIndex = 6;
            this.grpBoxEdit.TabStop = false;
            this.grpBoxEdit.Text = "Edit File Extension Defaults";
            // 
            // grpBoxDelete
            // 
            this.grpBoxDelete.Controls.Add(this.butClearAll);
            this.grpBoxDelete.Controls.Add(this.butDelCurrent);
            this.grpBoxDelete.Controls.Add(this.lblDeleteEntry);
            this.grpBoxDelete.Location = new System.Drawing.Point(21, 197);
            this.grpBoxDelete.Name = "grpBoxDelete";
            this.grpBoxDelete.Size = new System.Drawing.Size(266, 168);
            this.grpBoxDelete.TabIndex = 1;
            this.grpBoxDelete.TabStop = false;
            this.grpBoxDelete.Text = "Delete Entry";
            // 
            // butClearAll
            // 
            this.butClearAll.Location = new System.Drawing.Point(79, 113);
            this.butClearAll.Name = "butClearAll";
            this.butClearAll.Size = new System.Drawing.Size(125, 33);
            this.butClearAll.TabIndex = 9;
            this.butClearAll.Text = "Clear All Entries";
            this.butClearAll.UseVisualStyleBackColor = true;
            this.butClearAll.Click += new System.EventHandler(this.butClearAll_Click);
            // 
            // butDelCurrent
            // 
            this.butDelCurrent.Location = new System.Drawing.Point(79, 74);
            this.butDelCurrent.Name = "butDelCurrent";
            this.butDelCurrent.Size = new System.Drawing.Size(125, 33);
            this.butDelCurrent.TabIndex = 8;
            this.butDelCurrent.Text = "Delete Current Entry";
            this.butDelCurrent.UseVisualStyleBackColor = true;
            this.butDelCurrent.Click += new System.EventHandler(this.butDelCurrent_Click);
            // 
            // lblDeleteEntry
            // 
            this.lblDeleteEntry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteEntry.Location = new System.Drawing.Point(6, 28);
            this.lblDeleteEntry.Name = "lblDeleteEntry";
            this.lblDeleteEntry.Size = new System.Drawing.Size(254, 32);
            this.lblDeleteEntry.TabIndex = 0;
            this.lblDeleteEntry.Text = "Use the find button and then click on delete current entry";
            // 
            // grpBoxAdd
            // 
            this.grpBoxAdd.Controls.Add(this.butAddEntry);
            this.grpBoxAdd.Controls.Add(this.lblProgram);
            this.grpBoxAdd.Controls.Add(this.lblExtension);
            this.grpBoxAdd.Controls.Add(this.txtProgram);
            this.grpBoxAdd.Controls.Add(this.txtExtension);
            this.grpBoxAdd.Location = new System.Drawing.Point(21, 29);
            this.grpBoxAdd.Name = "grpBoxAdd";
            this.grpBoxAdd.Size = new System.Drawing.Size(266, 162);
            this.grpBoxAdd.TabIndex = 0;
            this.grpBoxAdd.TabStop = false;
            this.grpBoxAdd.Text = "Add Entry";
            // 
            // butAddEntry
            // 
            this.butAddEntry.Location = new System.Drawing.Point(79, 114);
            this.butAddEntry.Name = "butAddEntry";
            this.butAddEntry.Size = new System.Drawing.Size(125, 33);
            this.butAddEntry.TabIndex = 7;
            this.butAddEntry.Text = "Add New Entry";
            this.butAddEntry.UseVisualStyleBackColor = true;
            this.butAddEntry.Click += new System.EventHandler(this.butAddEntry_Click);
            // 
            // lblProgram
            // 
            this.lblProgram.AutoSize = true;
            this.lblProgram.Location = new System.Drawing.Point(19, 82);
            this.lblProgram.Name = "lblProgram";
            this.lblProgram.Size = new System.Drawing.Size(46, 13);
            this.lblProgram.TabIndex = 3;
            this.lblProgram.Text = "Program";
            // 
            // lblExtension
            // 
            this.lblExtension.AutoSize = true;
            this.lblExtension.Location = new System.Drawing.Point(19, 35);
            this.lblExtension.Name = "lblExtension";
            this.lblExtension.Size = new System.Drawing.Size(53, 13);
            this.lblExtension.TabIndex = 2;
            this.lblExtension.Text = "Extension";
            // 
            // txtProgram
            // 
            this.txtProgram.Location = new System.Drawing.Point(139, 75);
            this.txtProgram.Name = "txtProgram";
            this.txtProgram.Size = new System.Drawing.Size(100, 20);
            this.txtProgram.TabIndex = 1;
            // 
            // txtExtension
            // 
            this.txtExtension.Location = new System.Drawing.Point(139, 35);
            this.txtExtension.Name = "txtExtension";
            this.txtExtension.Size = new System.Drawing.Size(100, 20);
            this.txtExtension.TabIndex = 0;
            // 
            // frmFileExtensions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 450);
            this.Controls.Add(this.grpBoxEdit);
            this.Controls.Add(this.butListAll);
            this.Controls.Add(this.butFind);
            this.Controls.Add(this.txtFind);
            this.Controls.Add(this.lblText1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstExtensions);
            this.Name = "frmFileExtensions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "File Extensions";
            this.Load += new System.EventHandler(this.frmFileExtensions_Load);
            this.grpBoxEdit.ResumeLayout(false);
            this.grpBoxDelete.ResumeLayout(false);
            this.grpBoxAdd.ResumeLayout(false);
            this.grpBoxAdd.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstExtensions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblText1;
        private System.Windows.Forms.TextBox txtFind;
        private System.Windows.Forms.Button butFind;
        private System.Windows.Forms.Button butListAll;
        private System.Windows.Forms.GroupBox grpBoxEdit;
        private System.Windows.Forms.GroupBox grpBoxDelete;
        private System.Windows.Forms.Label lblDeleteEntry;
        private System.Windows.Forms.GroupBox grpBoxAdd;
        private System.Windows.Forms.Button butAddEntry;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.Label lblExtension;
        private System.Windows.Forms.TextBox txtProgram;
        private System.Windows.Forms.TextBox txtExtension;
        private System.Windows.Forms.Button butClearAll;
        private System.Windows.Forms.Button butDelCurrent;
    }
}

