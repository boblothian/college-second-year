<?php
    include 'includes/autoload.inc.php';
    include 'includes/header.inc.php';

?>

 
<div class = "fpage">
        <div class = "container">
            <div class = "home-banner"><img src = "images/bkb_logo.PNG"></div>
            <div class = "home-items">
                <!-- single box-->
                <div class = "fpage">
                    <div class = "home-content">
                        <div class = "home-img">
                            <a href = "products.php"><img src = "images/homepage_shop.jpg" alt = "Product Image"></a>
                        </div>
                    </div>
                </div>
                <!-- end of single box-->
                <!-- single box-->
                <div class = "fpage">
                    <div class = "home-content">
                        <div class = "home-img">
                            <a href = "services.php"><img src= "images/homepage_services.jpg" alt = "Services"></images></a>
                        </div>
                    </div>
                </div>
                <!-- end of single box-->
                <!-- single box-->
                <div class = "fpage">
                    <div class = "home-content">
                        <div class = "home-img">
                            <a href ="about.php"><img src= "images/homepage_about_us.jpg" alt = "About Us"></images></a>
                        </div>
                    </div>
                </div>
                <!-- end of single box-->
                <!-- single box-->
                <div class = "fpage">
                    <div class = "home-content">
                        <div class = "home-img">
                            <a href = "gallery.php"><img src= "images/homepage_gallery.jpg" alt = "Gallery"></images></a>
                        </div>
                    </div>
                </div>
                <!-- end of single box-->

                 <!-- banner -->
                 <div class = "fpage">
                    <div class = "home-content">
                        <div class = "banner-img">
                            <a href = "login.php"><img src= "images/register_banner.jpg" alt = "Login/Register"></images></a>
                        </div>
                    </div>
                </div>
                <!-- end of banner -->

                <script src="JavaScript/app.js"></script>
                <script src="JavaScript/nav.js"></script>
 

<?php

    include 'includes/footer.inc.php';

?>