<?php
    include 'includes/autoload.inc.php';
    include 'includes/header.inc.php';

    include 'includes/cards.inc.php';

    include 'includes/footer.inc.php';

?>

<script src="JavaScript/app.js"></script>
<script src="JavaScript/nav.js"></script>
