<?php 
    //include_once 'includes/dbc.inc.php';
    include 'includes/autoload.inc.php';
    ?>