<?php
    include "includes/indexhead.inc.php";
    include "includes/header.inc.php";
    include "includes/footer.inc.php";
    </?>