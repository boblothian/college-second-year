<?php

include 'includes/autoload.inc.php';

session_start();

$user = new Users("","","","","","","","","");
$login = new login();

if(isset($_SESSION['User_ID'])){

    $userID = $_SESSION['User_ID'];
    $user->deleteUser($userID);
    $login->deleteLogin($userID);
    $_SESSION = array();
    session_destroy();
    header('Location: index.php');
}

?>