
<?php

session_start();

include 'includes/header.inc.php';

$sql = "SELECT * FROM users";

$userName = $_SESSION['name'];

?>


<h1>Welcome <?php echo $_SESSION['name']; ?></h1>

<td>
<a href = "logout.php"><button class="btn log out"> Log Out</button>
<a href = "del-account.php" name= "delete"><button class="btn delete"> Delete Account</button>
<a href = "updateRec.php"><button class="btn change details"> Change Details</button>


<script src="JavaScript/app.js"></script>

</td>


<?php

include 'includes/footer.inc.php';

?>