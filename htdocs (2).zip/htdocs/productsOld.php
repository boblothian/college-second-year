<?php
    include 'includes/autoload.inc.php';
    include 'includes/header.inc.php';

?>

<div class = "products">
        <div class = "container">
            <h1 class = "lg-title">OUR PRODUCTS</h1>
            <p class = "text-light">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates eaque esse cumque ullam, minima, nihil laboriosam blanditiis a non reprehenderit harum! Ratione impedit dolore reiciendis voluptatem unde. Nam, officia nemo.</p>

            <div class = "product-items">
                <!-- single product-->
                <div class = "product">
                    <div class = "product-content">
                        <div class = "product-img">
                            <img src = "images/shop/bike_1.png" alt = "Product Image">
                        </div>
                    </div>
                    <div class = "product-info">
                        <div class = "product-info-top">
                            <h2 class = "sm-title">BIKES</h2>
                            <a href="a" class = "product-name">Carrero 6TF</a>
                            <p class ="product-price">£300.00</p>
                        </div>
                    </div>
                </div>
                <!-- end of single product-->

                <!-- single product-->
                <div class = "product">
                    <div class = "product-content">
                        <div class = "product-img">
                            <img src = "images/shop/bike_2.png" alt = "Product Image">
                        </div>
                    </div>
                    <div class = "product-info">
                        <div class = "product-info-top">
                            <h2 class = "sm-title">BIKES</h2>
                            <a href="a" class = "product-name">Carrero 5DT</a>
                            <p class ="product-price">£250.00</p>
                        </div>
                    </div>
                </div>
                <!-- end of single product-->

                <!-- single product-->
                <div class = "product">
                    <div class = "product-content">
                        <div class = "product-img">
                            <img src = "images/shop/bike_3.png" alt = "Product Image">
                        </div>
                    </div>
                    <div class = "product-info">
                        <div class = "product-info-top">
                            <h2 class = "sm-title">BIKES</h2>
                            <a href="a" class = "product-name">Mondo Express</a>
                            <p class ="product-price">£600.00</p>
                        </div>
                    </div>
                </div>
                <!-- end of single product-->

                <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/bike_4.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">BIKES</h2>
                        <a href="a" class = "product-name">Carrero Slant</a>
                        <p class ="product-price">£350.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->

            <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/bike_5.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">BIKES</h2>
                        <a href="a" class = "product-name">Boardman 500</a>
                        <p class ="product-price">£650.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->

            <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/bike_6.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">BIKES</h2>
                        <a href="a" class = "product-name">Indi 200</a>
                        <p class ="product-price">£200.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->

            <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/acc_1.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">Accessories</h2>
                        <a href="a" class = "product-name">Downhill Helmet</a>
                        <p class ="product-price">£25.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->

            <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/acc_2.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">Accessories</h2>
                        <a href="a" class = "product-name">BMX Helmet</a>
                        <p class ="product-price">£25.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->

            <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/acc_3.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">Accessories</h2>
                        <a href="a" class = "product-name">Waterbottle Holder</a>
                        <p class ="product-price">£10.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->

            <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/acc_4.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">Accessories</h2>
                        <a href="a" class = "product-name">Basket Rack</a>
                        <p class ="product-price">£15.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->

            <!-- single product-->
            <div class = "product">
                <div class = "product-content">
                    <div class = "product-img">
                        <img src = "images/shop/acc_5.png" alt = "Product Image">
                    </div>
                </div>
                <div class = "product-info">
                    <div class = "product-info-top">
                        <h2 class = "sm-title">Accessories</h2>
                        <a href="a" class = "product-name">Waterbottle</a>
                        <p class ="product-price">£5.00</p>
                    </div>
                </div>
            </div>
            <!-- end of single product-->
            </div>
        </div>
    </div>

<?php

    include 'includes/footer.inc.php';

?>