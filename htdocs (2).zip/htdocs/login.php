<?php

    include 'includes/autoload.inc.php';

    $found = false;
    $msg = null;

    session_start();

    if(isset($_SESSION['User_ID'])){

        header('Location:logout.php');

    }

    if(isset($_POST['login'])){

        $login = new Login();

        $userName = $_POST['name'];    
        $password = $_POST['pass'];
        $found = $login->validateLogin($userName, $password);

        if($found){

            $user = new Users("","","");
            $name = $user->gUserName($userName);
            $userID = $user->getUserID();
            $_SESSION['User_ID'] = $userID;
            $_SESSION['name'] = $userName;
            //$_SESSION['email'] = $userName;

    // Cookie Code - Set Cookie -------------------------------------------------

            if(!isset($_COOKIE["user"])){

                $lastVisitDate = date("d/m/Y");

                setcookie("user", $name, time()+(60*60*24*30));
                setcookie("visitDate", $lastVisitDate, time()+(60*60*24*30));
                setcookie("active", "true", time()+(60*60+24));

            }
            // ------------------------------------------------------------------

            header('Location: userpage.php');
        }
    }

    //register

    $update = false;

    if(isset($_POST['register'])){

        $email = $_POST['emailAdd'];
        $userName = $_POST['name'];
        $password = $_POST['pass'];

        $user = new Users("",$email, $userName);
        $update = $user->addUser();

    
        if($update){

            $login = new Login();
            $login->setUserName($userName);
            $login->setPassword($password);
            $login->addLogin();

        }

    }

    session_write_close();


    include 'includes/header.inc.php';

?>

<!DOCTYPE html>

<html lang="en">

    <div class = "hero">
        <div class = "form-box">
            <h2>To Register click right of Log In</h2>
            <div class = "button-box">
                <div id="btn"></div>
                <button type="button" class="toggle-btn" onclick="login()">Log In</button>
                <button type="button" class="toggle-btn" onclick="register()">Register</button>
            </div>
            <div class = "login-logo">
                <img src = "images/bkb_logo.PNG">
            </div>   

            <form id="login" class="input-group" method="post" action="login.php" onsubmit="validateLogin()">
                <input type="text" class="input-field" placeholder="User Name" name="name" required> 
                <input type="text" class="input-field" placeholder="Enter Password" name="pass" required> 
                <input type="checkbox" class="check-box"><span>Remember Password</span>
                <button type="submit" name="login" class="submit-btn">Log In</button>
                
            </form>
        
            <form id="register" class="input-group" method="post" action="login.php" onsubmit="validateRegForm()">
                <input type="text" class="input-field" name="name" placeholder="User Name" required> 
                <input type="email" class="input-field" name ="emailAdd" placeholder="Email Address" required> 
                <input type="text" class="input-field" name="pass" placeholder="Enter Password" required> 
                <input type="checkbox" class="check-box"><span>I agree to the terms & conditions</span>
                <button type="submit" name="register" class="submit-btn" >Register</button>
            </form>
        </div>
    </div>

<script src="JavaScript/app.js" ></script>

</html>

<?php

    include 'includes/footer.inc.php'

?>