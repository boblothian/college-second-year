<?php

class Users extends DB
{
    private $userID;
    private $emailAddress;
    private $userName;

    public function addUser(){

        $msg = "";
        $update = false;
        $found = $this->checkExistingUser();
    
        if(!$found){
        
            $sql = "INSERT INTO users (emailAddress, userName)
                    VALUE (:emailAddress, :userName)";
            try{
            
                $result = $this->dbConnect()->prepare($sql);
                $result->bindParam(':emailAddress', $this->emailAddress);    
                $result->bindParam(':userName', $this->userName);
                $result->execute();
                $update = true;
            }catch(PDOException $e){
               $msg = "<h1>" . $e->getMessage() . "</h1>";
            }
        
        } 
    
        return $update;
    
    }

    private function checkExistingUser() {

        $found = False;
        $sql = "SELECT emailAddress FROM users WHERE emailAddress = :emailAddress";
        
        try
        
        {
        
            $result = $this->dbConnect()->prepare($sql);
        
            $result->bindParam(':emailAddress', $this->emailAddress);
        
            $result->execute();
        
            $rows = $result->fetch(PDO::FETCH_NUM);
        
        if($rows > 0)
            {
                $found = True;
            }
        }
        
        catch(PDOException $e)
        
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }
    
        return $found;
    
    }
    
    public function deleteUser($userID){
    
        $sql = "DELETE FROM users WHERE userID = :userID";
        
        try
        
        {
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':userID', $userID);
            $result->execute();
        }
        
        catch(PDOException $e)
        
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }
    
    }
    
    public function listUsers(){
    
        $sql = "SELECT * FROM users";
        
        try
        
        {
            $result = $this->dbConnect()->query($sql);  /* We can query the result since we are not passing variables */
            $rows = $result->fetchAll(); 
        }
        
        catch(PDOException $e)
        
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }
        
        return $rows;
    
    }
    
    public function getUser($userID){
    
        $found = False;
        $sql = "SELECT * FROM users WHERE userID = :userID";
    
        try
        
        {
        
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':userID', $userID);
            $result->execute();
            $row = $result->fetch();
        
        if($row > 0){
        
            $found = True;
        
            $this->setUserID($row['userID']);
            $this->setEmailAddress($row['emailAddress']);
            $this->setFirstName($row['firstName']);
            $this->setLastName($row['lastName']);
            $this->setHouseNumber($row['houseNumber']);
            $this->setStreet($row['street']);
            $this->setCity($row['city']);
            $this->setSubscription($row['subscription']);
        
        }
        
        }
            catch(PDOException $e)
        {
        
        $msg = "<h1>" . $e->getMessage() . "</h1>";
        
        }
        return $found;
    
    }

}