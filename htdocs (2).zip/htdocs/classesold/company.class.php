<?php   /* Start of PHP statements */

class Company extends DB { /*Declare the class Company and extends to the DB class */


        private $companyName;    /* Set attributes */
        private $address_1;
        private $address_2;
        private $address_3;
        private $postCode;
        private $contactNumber;
        private $email;
        private $weekDayOpen;
        private $weekDayClose;
        private $saturdayOpen;
        private $saturdayClose;
        private $sundayOpen;
        private $sundayClose;

        

/* Methods to exist between here */

public function retrieveCompanyDetails(){

    $found = False;
    $sql = "SELECT * FROM company";
    
    
    try
    
    {
    
        $result = $this->dbConnect()->query($sql);
        $row = $result->fetch();
    
        if($row > 0){
    
            $found = True;
            
            $this->setCompanyName($row['companyName']);            
            $this->setAddress1($row['address_1']);       
            $this->setAddress2($row['address_2']);       
            $this->setAddress3($row['address_3']);      
            $this->setPostCode($row['postCode']);       
            $this->setContactNumber($row['contactNumber']);      
            $this->setEmail($row['email']);            
            $this->setWeekDayOpen($row['weekDayOpen']);
            $this->setWeekDayClose($row['weekDayClose']);            
            $this->setSaturdayOpen($row['saturdayOpen']);        
            $this->setSaturdayClose($row['saturdayClose']);            
            $this->setSundayOpen($row['sundayOpen']);            
            $this->setSundayClose($row['sundayClose']);            
        }
    
        }
    
    catch(PDOException $e)
    
    {
        $msg = "<h1>" . $e->getMessage() . "</h1>";
    }
    
    return $found;     

    }

    public function updateCompanyDetails(){

        $sql = "UPDATE company SET

        companyName = :companyName,
        address_1 = :address1,
        address_2 = :address2,
        address_3 = :address3,
        postCode = :postCode,
        contactNumber = :contactNumber,
        email = :email,

        weekDayOpen = :weekDayOpen,
        weekDayClose = :weekDayClose,
        saturdayOpen = :saturdayOpen,
        saturdayClose = :saturdayClose,
        sundayOpen = :sundayOpen,
        sundayClose = :sundayClose
        
        LIMIT 1";
        
        try
        
        {
        
            $result = $this->dbConnect()->prepare($sql);            
            $result->bindParam(':companyName', $this->companyName);            
            $result->bindParam(':address1', $this->address_1);            
            $result->bindParam(':address2', $this->address_2);            
            $result->bindParam(':address3', $this->address_3);            
            $result->bindParam(':postCode', $this->postCode);            
            $result->bindParam(':contactNumber', $this->contactNumber);            
            $result->bindParam(':email', $this->email);            
            $result->bindParam(':weekDayOpen', $this->weekDayOpen);            
            $result->bindParam(':weekDayClose', $this->weekDayClose);
            $result->bindParam(':saturdayOpen', $this->saturdayOpen);            
            $result->bindParam(':saturdayClose', $this->saturdayClose);            
            $result->bindParam(':sundayOpen', $this->sundayOpen);            
            $result->bindParam(':sundayClose', $this->sundayClose);            
            $result->execute();
        
        }
        
        catch(PDOException $e)
        
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }
        
    }

}   /* End of PHP Statement */