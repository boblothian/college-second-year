<?php

class Userhistory extends DB {

    private $userID;
    private $productID;

public function getUserID(){

        return $this->userID;

    }

 
public function setUserID($userID){

        $this->userID = $userID;

    }


public function getProductID(){

        return $this->productID;

    }

 

public function setProductID($productID){

        $this->productID = $productID;

    }

}

public function addToHistory($productID){

    if(isset($_SESSION['User_ID'])){
    
        $userID = $_SESSION['User_ID'];
        $found = $this->checkHistory($userID, $productID);
    
        if(!$found){
    
        $sql = "INSERT INTO userhistory (userID, productID) VALUES (:userID, :productID);";
    
        try
    
            {
    
                $result = $this->dbConnect()->prepare($sql);
                $result->bindParam(':userID', $userID);
                $result->bindParam(':productID', $productID);
                $result->execute();
    
            }
    
        catch(PDOException $e)
    
            {
    
                $msg = "<h1>" . $e->getMessage() . "</h1>";
    
            }
    
        }
    
    }
    
}

public function checkHistory($userID, $productID){

    $found = False;
    $sql = "SELECT * FROM userhistory WHERE userID = :userID AND productID = :productID";
    
    try

    {
    
        $result = $this->dbConnect()->prepare($sql);
        $result->bindParam(':userID', $userID);
        $result->bindParam(':productID', $productID);
        $result->execute();
        $row = $result->fetch(PDO::FETCH_NUM);
    
        if($row > 0){
    
            $found = True;
    
        }
    
    }
    
    catch(PDOException $e)
    
    {
        $msg = "<h1>" . $e->getMessage() . "</h1>";
    }
    
    return $found;
    
}

public function deleteHistory($userID){

    $sql = "DELETE FROM userhistory WHERE userID = :userID";
    
    try
    
    {
    
        $result = $this->dbConnect()->prepare($sql);
        $result->bindParam(':userID', $userID);
        $result->execute();
    
    }
    
    catch(PDOException $e)
    
    {
    
        $msg = "<h1>" . $e->getMessage() . "</h1>";
    
    }
    
}

public function deleteProductHistory($productID){

    $sql = "DELETE FROM userhistory WHERE productID = :productID";
    
    try
    
    {
    
        $result = $this->dbConnect()->prepare($sql);
        $result->bindParam(':productID', $productID);
        $result->execute();
    
    }
    
    catch(PDOException $e)
    
    {
    
        $msg = "<h1>" . $e->getMessage() . "</h1>";
    
    }
    
}

public function deleteProductHistory($productID){

    $sql = "DELETE FROM userhistory WHERE productID = :productID";

    try
    
    {
        
        $result = $this->dbConnect()->prepare($sql);
        $result->bindParam(':productID', $productID);
        $result->execute();
    
    }
    
    catch(PDOException $e)
    
    {
    
        $msg = "<h1>" . $e->getMessage() . "</h1>";
    
    }
}

public function addLogin(){

    $found = $this->checkExistingLogin();
    
    if(!$found){
    
        $sql = "INSERT INTO logins (emailAddress, password, salt) VALUE(:emailAddress, :pword, :salt)";
    
        try
    
        {
    
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':emailAddress', $this->emailAddress);
            $result->bindParam(':pword', $this->password);
            $result->bindParam(':salt', $this->salt);
            $result->execute();
    
        }
    
        catch(PDOException $e)
    
        {
    
            $msg = "<h1>" . $e->getMessage() . "</h1>";
    
        }
    
    }
    
    else
    
    {
        $msg = "<h1> Record already exists</h1>";
    }
    
}

private function checkExistingLogin() {

    $found = False;
    $sql = "SELECT emailAddress FROM logins WHERE emailAddress = :emailAddress";
    
    try
    
    {
    
        $result = $this->dbConnect()->prepare($sql);
        $result->bindParam(':emailAddress', $this->emailAddress);
        $result->execute();
        $rows = $result->fetch(PDO::FETCH_NUM);
    
        if($rows > 0){
    
            $found = True;
    
        }
    }
    
    catch(PDOException $e)
    
    {
        $msg = "<h1>" . $e->getMessage() . "</h1>";
    }
    
    return $found;
} 

public function validateLogin($eAddress, $pword){

    $found = False;
    $sql = "SELECT password, salt FROM logins WHERE emailAddress = :emailAddress";
    
    try
    
    {
    
        $result = $this->dbConnect()->prepare($sql);
        $result->bindParam(':emailAddress', $eAddress);
        $result->execute();
        $row = $result->fetch(PDO::FETCH_ASSOC);
    
        if($row > 0){
    
            if(password_verify($pword, $row['password'])){
    
                $found = True;
            }
    
            else
    
                {
                    $msg = "<h1>Email address or Password incorrect.</h1>";
                }
    
        }
    
        else
    
        {
            $msg = "<h1>Email address or Password incorrect.</h1>";
        }
    
    }

        catch(PDOException $e)
    {
        $msg = "<h1>" . $e->getMessage() . "</h1$row>";
    }
    
    return $found;
    
}

public function deleteLogin($userID){

    $sql = "DELETE FROM logins WHERE userID = :userID";
 
    try
    
    {
        $result = $this->dbConnect()->prepare($sql);
        $result->bindParam(':userID', $userID);
        $result->execute();
    }
    
    catch(PDOException $e)
    
    {
        $msg = "<h1>" . $e->getMessage() . "</h1>";
    }
    
}