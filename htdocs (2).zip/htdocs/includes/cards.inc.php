<?php

 
$products = new Products();  // Create an instance of the object Products //
$rows = $products->retrieveProducts();  // Call the method retrieveProducts() from inside Products //
$record = 0;  // Create a variable for looping around returned rows //

 

echo '<div class = "products">';  // Output HTML - class cards //
echo '    <div class = "container">';
echo '        <h1 class = "lg-title">OUR PRODUCTS</h1>';
echo '        <p class = "text-light">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates eaque esse cumque ullam, minima, nihil laboriosam blanditiis a non reprehenderit harum! Ratione impedit dolore reiciendis voluptatem unde. Nam, officia nemo.</p>';
echo '        <div class = "product-items">';

while($record < count($rows)){  // Loop while outputing data //

// The echo commands will output HTML returing the values in the array //

echo '<div class = "product">';
echo '<div class = "product-content">';
echo '    <div class = "product-img">';
echo '          <img src="data:image/jpeg;base64,' . base64_encode($rows[$record]['image']) . '"alt="' . $rows[$record]['productName'] . '"/>';
echo '    </div>';
echo '</div>';
echo '<div class = "product-info">';
echo '    <div class = "product-info-top">';
echo '        <h2 class = "sm-title">'.$rows[$record]['category'].'</h2>';
echo '        <a href="a" class = "product-name">'.$rows[$record]['productName'].'</a>';
echo '        <p class ="product-price">'.$rows[$record]['price'].'</p>';
echo '    </div>';
echo '</div>';
echo '</div>';

$record++;  // Increment record //

}
echo '        </div>';
echo '    </div>';
echo '</div>';

?>