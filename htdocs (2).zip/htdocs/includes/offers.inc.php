<?php


$offers = new Offers();
$rows = $offers->listOffers();
$record = 0;

echo '<h1 class="cards-banner">Current Offers</h1>';
echo '<section class="cards">';

 

while($record < count($rows)){

    echo '<a href="productItem.php?productCode=' . $rows[$record]['productCode'] .'">';
    echo '  <div class="card">';
    echo '      <h3 class="card-title">'.$rows[$record]['productName'].'</h3>';
    echo '      <div class="card-image">';
    echo '          <img src="data:image/jpeg;base64,' . base64_encode($rows[$record]['image']) . '" alt="' . $rows[$record] ['productName'] . '"/>';
    echo '      </div>';
    echo '      <h2 class="productPrice standard-price">£ '.$rows[$record]['price'].'</h2>';
    echo '      <h2 class="productSale">£ '.$rows[$record]['sprice'].'</h2>';
    echo '  </div>';
    echo '</a>';

    $record++;

}

echo '</section>';

?>