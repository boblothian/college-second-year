<?php

if(isset($_SESSION['User_ID'])){

$products = new Products();
$rows = $products->userHistory();
$record = 0;

    if(count($rows)> 0){

        echo '<section class="slider">';
        echo '<h2 class="slide-header">History</h2>';
        echo '<div class="slide-cards">';

    while($record < count($rows)){

        echo '<div class="slide-card">';
        echo '  <a href="productItem.php?productCode='.$rows[$record]['productCode'].'">';
        echo '      <div class="slide-image">';
        echo '          <img src="data:image/jpeg;base64,' . base64_encode($rows[$record]['image']) . '" alt=""/>';
        echo '      </div>';
        echo '      <h4 class="slide-cost">' . $rows[$record]['price'] . '</h4>';
        echo '  </a>';
    echo '</div>';

$record++;

}

echo '</div>';
echo '</section>';

}

?>