<section class="card-container">
        <div class="card card-1">
            <img src="./images/shop.png" alt="shop">
            <h2>Bikes</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam fugiat consectetur esse natus eius asperiores aliquid atque at mollitia blanditiis voluptatem quisquam nihil ducimus eaque, iusto totam omnis ab obcaecati voluptas dolor. Excepturi error atque voluptas minus saepe suscipit tenetur.</p>
            <button><a href="#">Shop Now</a></button>
        </div>
        <div class="card card-2">
            <img src="./images/clothing.png" alt="shop">
            <h2>Clothing</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam fugiat consectetur esse natus eius asperiores aliquid atque at mollitia blanditiis voluptatem quisquam nihil ducimus eaque, iusto totam omnis ab obcaecati voluptas dolor. Excepturi error atque voluptas minus saepe suscipit tenetur.</p>
            <button><a href="#">Shop Now</a></button>
        </div>
        <div class="card card-3">
            <img src="./images/accessories.png" alt="shop">
            <h2>Accessories</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam fugiat consectetur esse natus eius asperiores aliquid atque at mollitia blanditiis voluptatem quisquam nihil ducimus eaque, iusto totam omnis ab obcaecati voluptas dolor. Excepturi error atque voluptas minus saepe suscipit tenetur.</p>
            <button><a href="#">Shop Now</a></button>
        </div>
        <div class="card card-4">
            <img src="./images/trails.png" alt="shop">
            <h2>Trails</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam fugiat consectetur esse natus eius asperiores aliquid atque at mollitia blanditiis voluptatem quisquam nihil ducimus eaque, iusto totam omnis ab obcaecati voluptas dolor. Excepturi error atque voluptas minus saepe suscipit tenetur.</p>
            <button><a href="#">Visit Now</a></button>
        </div>
      

    </section>