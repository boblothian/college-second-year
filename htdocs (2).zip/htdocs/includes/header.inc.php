<?php

$found = false;

if(isset($_SESSION['User_ID'])){
    $found = true;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style> @import url('https://fonts.googleapis.com/css2?family=Lato:wght@100&display=swap');</style>
    <link rel="stylesheet" href="CSS/style.css">
    <title>Bike King Borders</title>
</head>
<body>
    <nav>
        <div class ="logo">
            <h4>Bike King Borders</h4>
        </div>
        <ul class="nav-links">
            <li><a href="index.php" accesskey = "h"> Home </a></li>
            <li><a href="about.php" accesskey = "a">About</a></li>
            <li><a href="products.php" accesskey = "p">Products</a></li>
            <li><a href="services.php" accesskey = "s">Services</a></li>
            <li><a href="gallery.php " accesskey = "g">Gallery</a></li>
            <?php
               if($found){
                echo '<li><a href="logout.php" accesskey = "l">Logout</a></li>';
               } else {
                 echo '<li><a href="login.php" accesskey = "l">Login/Register</a></li>';
               }
            ?>
        </ul>
        <div class = "burger">
            <div class ="line1"></div>
            <div class ="line2"></div>
            <div class ="line3"></div>
        </div>
    </nav>