<div class="footer-container">
        <div class="footer">
            <div class="footer-heading footer-1">
                <h2>About Us</h2>
                <p>123, Fake St, Glasgow G54 9GD</p>
                <p>Open Mon - Sat 10am - 6pm</p>
                <p href="#">Sunday 12 noon - 5pm</p>
            </div>
            <div class="footer-heading footer-2">
                <h2>Contact Us</h2>
                <a href="#">Email</a>
                <a href="#">Phone</a>
                <a href="#">Support</a>
            </div> 
            <div class="footer-heading footer-3">
                <h2>Social Media</h2>
                <a href="#">Instagram</a>
                <a href="#">Facebook</a>
                <a href="#">YouTube</a>
                <a href="#">Twitter</a>
            </div> 
            <div class="footer-email-form">
                <h2>Join our newsletter</h2>
                <input type="email" placeholder="Enter your email address" id="footer-email">
                <input type="submit" value="Sign Up" id="footer-email-btn">
            </div>
        </div>
    </div>

    <script src="JavaScript/app.js"></script>
</body>

</html>