<?php

$products = new Products();
$category = "clothing";
$rows = $products->retrieveCategory($category);
$record = 0;

 

echo '<section class="slider">';
echo '<h2 class="slide-header">Clothing</h2>';
echo '<div class="slide-cards">';

 

while($record < count($rows)){

    echo '<div class="slide-card">';
    echo '  <a href="productItem.php?productCode='.$rows[$record]['productCode'].'">';
    echo '      <div class="slide-image">';
    echo '          <img src="data:image/jpeg;base64,' . base64_encode($rows[$record]['image']) . '" alt=""/>';
    echo '      </div>';
    echo '      <h4 class="slide-cost">' . $rows[$record]['price'] . '</h4>';
    echo '  </a>';
    echo '</div>';

    $record++;

}

echo '</div>';
echo '</section>';

?>