<?php

include 'includes/header.inc.php';

?>

<h1>About Us</h1>

<script src="JavaScript/app.js"></script>
<script src="JavaScript/nav.js"></script>

<?php
include 'includes/footer.inc.php';

?>