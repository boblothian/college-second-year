<?php

    if(isset($_POST['yes'])){

        session_start();
        $_SESSION = array();
        session_destroy();
        header("Location:index.php");

    }


    if(isset($_POST['no'])){

        header("Location:index.php");

    }

?>


<!DOCTYPE html>

    <html lang="en">

        <head>

            <meta charset="utf-8">

                <title>Title Here</title>

                    <meta name="author" content="Your name here">
                    <meta name="description" content="Description here">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">

                    <link rel="stylesheet" href="css/style.css">
                    <link rel="preconnect" href="https://fonts.gstatic.com">
                    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&family=Roboto&display=swap" rel="stylesheet">

                    <script src="https://kit.fontawesome.com/3830352c3e.js" crossorigin="anonymous"></script>

        </head>

    <body>

        <main>

            <section class="forms">

                <div class="data-form">
                    <h1 class="data-form-header">Logout</h1>
                    <form class="form" method="post" action="logout.php" name="logout">
                        <p>Do you wish to logout?</p>
                        <input class="button yes" type="submit" name="yes" value="Yes">
                        <input class="button no" type="submit" name="no" value="No">
                    </form>
                </div>
            </section>
        </main>
    </body>
</html>