<?php

    include 'includes/autoload.inc.php';
    include 'includes/header.inc.php';

?>

<!DOCTYPE html>
<html lang="en">

    <body>

        <section aria-label="photos">
            <div class= "carousel" data-carousel>
                <button class = "carousel-button prev" data-carousel-button= "prev" >&#x21a9;</button>
                <button class = "carousel-button next" data-carousel-button= "next" >&#x21aa;</button>
                <ul data-slides>
                    <li class = "slide" data-active>
                        <img src="images/gallery1.jpg" alt="Trail 1">
                    </li>
                    <li class = "slide">
                        <img src="images/gallery2.jpg" alt="Trail 2">
                    </li>
                    <li class = "slide">
                        <img src="images/gallery3.jpg" alt="Trail 3">
                    </li>
                    <li class = "slide">
                        <img src="images/gallery4.jpg" alt="Trail 4">
                    </li>
                </ul>
            </div>
        

        </section>

        <script src="JavaScript/carousel.js"></script>
        <script src="JavaScript/app.js"></script>
        <script src="JavaScript/nav.js"></script>
        
    </body>

</html>

