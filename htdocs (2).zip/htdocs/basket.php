<?php

include 'includes/header.inc.php';


$basketItem = new Basketitems();
$total = 0;


if(isset($_GET['productID'])){

    $productID = $_GET['productID'];

    if(!isset($_GET['action'])){

        $basketItem->createNewBasketItem($productID, 1);

    }   

    else if(isset($_GET['action'])){

        if($_GET['action']=="del"){

            $basketItem->deleteBasketItem($productID);

        }

    }

}


$rows = $basketItem->listBasket();
$record = 0;

?>


<h1 class="basket-header">Shopping Basket</h1>
<div class="basket">

    <?php

    while($record < count($rows)){

        echo '<div class="basketItem">';
        echo '  <div class="productImage">';
        echo '      <p class="productImg"><img class="listImage" id="productItem" src="data:image/jpeg;base64,' .
        base64_encode($rows[$record]['image']) . '" alt=""/></p>';
        echo '  </div>';
        echo '  <div class="basket_details">';
        echo '      <p class="productCode">Code - '.$rows[$record]['productCode'].'</p>';
        echo '      <p class="productName">'.$rows[$record]['productName'].'</p>';
        echo '      <p class="productPrice">£ '.$rows[$record]['price'].'</p>';
        echo '      <p class="productQuantity">Qty - '.$rows[$record]['quantity'].'</p>';
        echo '  </div>';
        echo '  <p class="basketItem-delete"><a href="basket.php?productID='.$rows[$record]['productID'].'&action=del"><i class="fas fa-trash-alt"></i></a></p>';
        echo '</div>';

        $total = $total + ($rows[$record]['price'] * $rows[$record]['quantity']);

        $record++;

    }

    ?>

</div>

<div class="basket-total">

    <h1>Total</h1>
    <h1>£ <?=number_format($total, 2, ".", ",");?></h1>

</div>

<button type="button" class="button pay">Proceed to Payment</button>


<?php

    include 'includes/footer.inc.php';

?>