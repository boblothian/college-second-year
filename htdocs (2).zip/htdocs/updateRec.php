<?php

include 'includes/autoload.inc.php';

session_start();

$user = new Users("","","","","","","","","");

if(isset($_SESSION['User_ID'])){

    $userID = $_SESSION['User_ID'];

    if(isset($_POST['update'])){
        $userName = $_POST['name'];
        $emailAddress = $_POST['email'];
        
        $user->upDateUser($userName, $emailAddress);
        header('Location: index.php');

    }else {

        $foundUser = $user->getUser($userID);
        if($foundUser){
            $userName = $user->getName();
            $emailAddress = $user->getEmailAddress();
            
        } else {
            echo 'User not found';
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Title Here</title>
        <meta name="author" content="Your name here">
        <meta name="description" content="Description here">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&family=Roboto&display=swap" rel="stylesheet"> 
        <script src="https://kit.fontawesome.com/3830352c3e.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <main>
            <h1 class="admin-header">Edit User</h1>
            <section class="forms">
                <div class="data-form">
                    <form class="form" method="POST" action="updateRec.php" name="edit">
                        <input class="input" type="hidden" name="userID" id="userID" value="<?= $userID ?>">
                        <label class="label" for="name">User Name</label>
                        <input class="input" type="text" name="name" id="name" value="<?= $userName ?>" required autofocus>
                        <label class="label" for="email">Email Address</label>
                        <input class="input" type="text" name="email" id="email" value="<?= $emailAddress ?>" required>
    
                        <input class="button" type="submit" name="update" id="update" value="Update">                        
                    </form>
                </div>
            </section>            
        </main>
    </body>
</html>