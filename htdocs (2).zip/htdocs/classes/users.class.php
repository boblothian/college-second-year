<?php

class Users extends DB {

    private $userID;
    private $emailAddress;
    private $userName;

    public function __construct($userID, $emailAddress, $userName) {
        $this->userID = $userID;
        $this->emailAddress = $emailAddress;
        $this->userName = $userName;
    }

    public function getUserID(){
        return $this->userID;
    }

    public function setUserID($userID){
        $this->userID = $userID;
    }

    public function setEmailAddress($emailAddress){
        $this->emailAddress = $emailAddress;
    }

    public function getEmailAddress(){
        return $this->emailAddress;
    }

    public function setUserName($userName){
        $this->userName = $userName;
    }

    public function getUserName(){
        return $this->userName;
    }    

    private function checkExistingUser() {

        $found = False;

        $sql = "SELECT emailAddress FROM users WHERE emailAddress = :emailAddress";

        try
        {
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':emailAddress', $this->emailAddress);
            $result->execute();

            $rows = $result->fetch(PDO::FETCH_NUM);
            if($rows > 0){
                $found = True;
            }
        }
        catch(PDOException $e)
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }

        return $found;
    }     

    public function addUser(){

        $msg = "";
        $update = false;
        $found = $this->checkExistingUser();

        if(!$found){

            $sql = "INSERT INTO users (emailAddress, userName) 
                    VALUE (:emailAddress, :userName)";
            
            try
            {
                $result = $this->dbConnect()->prepare($sql);
                $result->bindParam(':emailAddress', $this->emailAddress);
                $result->bindParam(':userName', $this->userName);
                $result->execute();
                $update = true;
            }
            catch(PDOException $e)
            {
                $msg = "<h1>" . $e->getMessage() . "</h1>";
            }
        }
        else
        {
            $msg = "<h1>Record already exists</h1>";
        }

        return $update;

    }    

        public function listUsers(){

            $sql = "SELECT * FROM users";

            try
            {
                $result = $this->dbConnect()->query($sql);
                $rows = $result->fetchAll();

            }
            catch(PDOException $e)
            {
                $msg = "<h1>" . $e->getMessage() . "</h1>";
            }

            return $rows;
        }

    public function deleteUser($userID){

        $sql = "DELETE FROM users WHERE userID = :userID";

        try
        {
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':userID', $userID);
            $result->execute();
        }
        catch(PDOException $e)
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }
    }

    public function upDateUser($userID, $userName){
        $sql = "UPDATE users 
                SET userName = :userName,
                WHERE userID = :userID";

        try
        {
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':userID', $userID);
            $result->bindParam(':userName', $userName);
            $result->execute();
        }
        catch(PDOException $e)
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }
    }

    public function getUser($userID){
        $found = False;

        $sql = "SELECT * FROM users WHERE userID = :userID";

        try
        {
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':userID', $userID);
            $result->execute();
            
            $row = $result->fetch();
            if($row > 0){
                $found = True;
                $this->setUserID($row['userID']);
                $this->setEmailAddress($row['emailAddress']);
                $this->setUserName($row['userName']);
            }
        }
        catch(PDOException $e)
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }

        return $found;
    }

    public function getName(){

        $name = "";
        $sql = "SELECT userID, emailAddress, userName";

        try
        {
            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':emailAddress', $this->emailAddress);
            $result->execute();

            $row = $result->fetch(PDO::FETCH_ASSOC);
            if($row > 0){
                $this->setUserID($row['userID']);
                $name = $row['userName'];
            }
        }
        catch(PDOException $e)
        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }

        return $name;

    }

    public function gUserName($name){

        $found = False;



        $sql = "SELECT * FROM users WHERE userName = :name";



        try

        {

            $result = $this->dbConnect()->prepare($sql);
            $result->bindParam(':name', $name);
            $result->execute();

            $row = $result->fetch();

            if($row > 0){
                $found = True;
                $this->setUserID($row['userID']);
                $this->setEmailAddress($row['emailAddress']);
                $this->setUserName($row['userName']);

            }

        }

        catch(PDOException $e)

        {
            $msg = "<h1>" . $e->getMessage() . "</h1>";
        }

        return $this->userName;

    }

}