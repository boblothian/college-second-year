<?php


include 'includes/header.inc.php';


if(isset($_GET['productCode'])){

    $productCode = $_GET['productCode'];
    $product = new Products();
    $product->retrieveOneProduct($productCode);
    $productID = $product->getProductID();
    $productCode = $product->getProductCode();
    $productName = $product->getProductName();
    $manufacturer = $product->getManufacturer();
    $productDesc = $product->getProductDesc();
    $price = $product->getPrice();
    $category = $product->getCategory();
    $image = $product->getImage();

};

 

echo '<div class="productSelect">';
echo '  <h5 class="productCode"><span class="bold">Product Code -

</span>'.$productCode.'</h5>';

echo '  <h5 class="productCode"><span class="bold">Manufacturer -

</span>'.$manufacturer.'</h5>';

echo '  <h1 class="productDesc">'.$productName.'</h1>';
echo '  <div class="productImage">';
echo '      <img class="productImg" id="productItem" src="data:image/jpeg;base64,' .
base64_encode($image) . '" alt=""/>';
echo '      <h2 class="productPrice">£ '.$price.'</h2>';
echo '      <button class="button" type="button">Buy</button>';
echo '  </div>';
echo '</div>';
echo '<script src=js/zoom.js></script>';
echo '<script>';
echo '  const buyButton = document.querySelector(".button");';
echo '   buyButton.addEventListener("click", function(){';
echo '      window.location.href = "basket.php?productID='.$productID.'";';
echo '   });';

echo '</script>';

 

include 'includes/relatedproducts.inc.php';

include 'includes/footer.inc.php';

?>