const navSlide =() => {
    const burger = document.querySelector('.burger');
    const nav = document.querySelector('.nav-links');
    const navLinks = document.querySelectorAll('.nav-links li');

    burger.addEventListener('click', ()=>{
        //toggle navigation
        nav.classList.toggle('nav-active');

        //animate links
        navLinks.forEach((link, index) => {
            if (link.style.animation) {
                link.style.animation = ''
            } else {
                link.style.animation = `navLinkFade 0.5s ease forwards ${index /7 + 0.6}s`;
            }
        }); 
        //burger animation
        burger.classList.toggle('toggle');    
    });
}

/*app function to call smaller functions*/

//THIS HANDLES LOGIN REGISTRATION SLIDE EFFECT
const app = ()=>{
    navSlide();
}


        var x = document.getElementById("login");
        var y = document.getElementById("register");
        var z = document.getElementById("btn");

        function register(){
                x.style.left = "-400px";
                y.style.left = "50px";
                z.style.left = "100px";
        }

        function login(){
                x.style.left = "50px";
                y.style.left = "450px";
                z.style.left = "0px";
        }
    

         //***THIS HANDLES REGISTRATION FORM CHECKING***
        
         function validateRegForm(){
            var uName = document.getElementById("register").name;
            var uEmail = document.getElementById("register").emailAdd;
            var uPass = document.getElementById("register").pass;

            //1.1 Check username value
            if (uName.value == "" || uName.value.length <=4){
                alert("Username must be at least 4 characters long")
                uName.focus();
                event.preventDefault();
            }

            //1.2 Check Email Value
            if(uEmail.value == ""){
                alert("Email must be provided");
                uEmail.focus();
                event.preventDefault();
            }

            //1.3 Check password value
            if(uPass.value == ""|| uPass.value.length <6){
                alert("Password must be at least 6 characters long");
                uPass.focus();
                event.preventDefault();
            }
        }

        function validateLogin(){
            var uName = document.getElementById("login").name;
            var uPass = document.getElementById("login").pass;

            //2.1 Check username value
            if (uName.value == "" || uName.value.length <=4){
                alert("Username must be at least 4 characters long")
                uNam.focus();
                event.preventDefault();
            }

            //2.2 Check password value
            if(uPass.value == ""|| uPass.value.length <6){
                alert("Password must be at least 6 characters long");
                uPass.focus();
                event.preventDefault();
            }
        }



app();