// Create a EventListener event when a key is pressed down
document.addEventListener('keydown', (event) => {  
    var name = event.key;  // Pass the key press to name variable
    var code = event.code;  // Pass the key code to the code variable
    event.preventDefault();  // Disable any default key options

    if(name == "h" || name == "H"){  // Check to see if the h/H key has been pressed
        window.location.href="index.php";  // if so go to home page
    }

    if(name == "p" || name == "P"){  // Check to see if the p/P key has been pressed
        window.location.href="products.php";  // if so go to products page
    }

    if(name == "g" || name == "G"){  // Check to see if the g/G key has been pressed
        window.location.href="gallery.php";  // if so go to Gallery page
    }

    if(name == "a" || name == "A"){  // Check to see if the a/A key has been pressed
        window.location.href="about.php";  // if so go to about page
    }

    if(name == "s" || name == "S"){  // Check to see if the s/S key has been pressed
        window.location.href="services.php";  // if so go to services page
    }
    
  }, false);