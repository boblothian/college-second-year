
        var x = document.getElementById("login");
        var y = document.getElementById("register");
        var z = document.getElementById("btn");

        function register(){
                x.style.left = "-400px";
                y.style.left = "50px";
                z.style.left = "100px";
        }

        function login(){
                x.style.left = "50px";
                y.style.left = "450px";
                z.style.left = "0px";
        }
    

         //***THIS HANDLES REGISTRATION FORM CHECKING***

         function validateRegForm(){
            var uName = document.getElementById("register").name;
            var uEmail = document.getElementById("register").emailAdd;
            var uPass = document.getElementById("register").pass;

            //2.1 Check username value
            if (uName.value == "" || uName.value.length <=4){
                alert("Username must be at least 4 characters long")
                uNam.focus();
                event.preventDefault();
            }

            //2.2 Check Email Value
            if(uEmail.value == ""){
                alert("Email must be provided");
                uEmail.focus();
                event.preventDefault();
            }

            //2.3 Check password value
            if(uPass.value == ""|| uPass.value.length <6){
                alert("Password must be at least 6 characters long");
                uPass.focus();
                event.preventDefault();
            }
        }

        function validateLogin(){
            var uName = document.getElementById("login").name;
            var uPass = document.getElementById("login").pass;

            //2.1 Check username value
            if (uName.value == "" || uName.value.length <=4){
                alert("Username must be at least 4 characters long")
                uNam.focus();
                event.preventDefault();
            }

            //2.2 Check password value
            if(uPass.value == ""|| uPass.value.length <6){
                alert("Password must be at least 6 characters long");
                uPass.focus();
                event.preventDefault();
            }
        }
